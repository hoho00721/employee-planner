## Attribution

Based on project 「تطبيق حسب الوصف المرفق」 by author Hocine BIRECH @hocinebirech96.
Create with HappySeeds: https://happyseeds.ai
