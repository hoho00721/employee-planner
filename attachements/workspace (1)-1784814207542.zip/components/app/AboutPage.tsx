'use client'

export default function AboutPage({ isLight = false, isFr = false }: { isLight?: boolean; isFr?: boolean }) {
  return (
    <div className="space-y-3">
      <div className="glass-card p-6 text-center">
        <div className="text-6xl mb-4">📅</div>
        <h2 className="text-white font-bold text-2xl mb-1">منظم الموظف</h2>
        <p className="text-indigo-300 text-sm">Employee Planner</p>
        <p className="text-white/40 text-xs mt-1">الإصدار 1.0.0</p>
      </div>

      <div className="glass-card p-5">
        <h3 className="text-white font-semibold mb-3">🎯 عن التطبيق</h3>
        <p className="text-white/60 text-sm leading-relaxed">
          منظم الموظف هو مساعد شخصي ذكي لإدارة الحياة المهنية والشخصية للموظف.
          يهدف التطبيق إلى مساعدتك على تنظيم وقتك وإجازاتك ومهامك ومواعيدك بكل سهولة ويسر.
        </p>
      </div>

      <div className="glass-card p-5">
        <h3 className="text-white font-semibold mb-3">✨ المميزات الرئيسية</h3>
        <div className="space-y-2.5">
          {[
            { icon: '📅', text: 'تقويم تفاعلي ذكي مع ترميز لوني' },
            { icon: '📋', text: 'إدارة المهام والمواعيد والمناسبات' },
            { icon: '🌴', text: 'إدارة الإجازات السنوية والتعويضية' },
            { icon: '📝', text: 'ملاحظات ذكية مرتبطة بالتقويم' },
            { icon: '📊', text: 'إحصائيات ورسوم بيانية احترافية' },
            { icon: '🔔', text: 'نظام تنبيهات ذكي لجميع الأحداث' },
            { icon: '📦', text: 'أرشيف متكامل مع بحث وفلترة' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xl">{item.icon}</span>
              <span className="text-white/60 text-sm">{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-card p-5">
        <h3 className="text-white font-semibold mb-3">🛠️ التقنيات المستخدمة</h3>
        <div className="flex flex-wrap gap-2">
          {['Next.js', 'React 19', 'TypeScript', 'PostgreSQL', 'Drizzle ORM', 'Tailwind CSS', 'Recharts'].map(tech => (
            <span key={tech} className="bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 text-xs px-3 py-1.5 rounded-full">
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
